# Mind the Interface — synthesized Codex draft

Set main.tex as the main document and compile with pdfLaTeX. The supplied ACL style is unmodified. All figures are native TikZ/PGFPlots, with separate PDF exports. No external images, Python, experiment data or machine paths are needed.

Working research draft, measured pilot snapshot dated October 10, 2026. Official 16k results are complete; the main table uses three R1 training seeds on SPEED, seed 0 on full MATH-500, and one Nemotron seed. The research repository retains data provenance and raw checks.
